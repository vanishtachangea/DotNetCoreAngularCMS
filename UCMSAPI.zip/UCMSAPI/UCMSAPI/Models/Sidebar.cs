﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UCMSAPI.Models
{
    public class Sidebar
    {
        public int ID { get; set; }
        public String Content { get; set; }
    }
}
